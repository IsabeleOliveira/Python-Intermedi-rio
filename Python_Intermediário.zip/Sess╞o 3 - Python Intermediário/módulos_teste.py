import módulos

print(módulos.PI)

lista = [2, 4]
print(módulos.multiplica(lista))





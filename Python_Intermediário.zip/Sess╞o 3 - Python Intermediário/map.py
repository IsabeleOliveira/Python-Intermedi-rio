pessoas = [
    {'nome': 'isabele', 'idade': 20},
    {'nome': 'Rafaela', 'idade': 25},
    {'nome': 'lara', 'idade': 21},
    {'nome': 'luana', 'idade': 19},
    {'nome': 'camila', 'idade': 17},
]

produtos = [
    {'produto': 'p1', 'preço': 40},
    {'produto': 'p2', 'preço': 20},
    {'produto': 'p3', 'preço': 34},
    {'produto': 'p4', 'preço': 25},
    {'produto': 'p5', 'preço': 22},
    {'produto': 'p6', 'preço': 3.20},

]


lista = [1, 2, 3, 4, 5, 6, 7, 8]



